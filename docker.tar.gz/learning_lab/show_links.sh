#!/bin/bash
printf "\nStatic Docker container: http://172.31.0.9:%s/\n" "$(expr 10000 + ${UID})"
printf "\nDocker container with host volume: http://172.31.0.9:%s/\n" "$(expr 11000 + ${UID})"
printf "\n"